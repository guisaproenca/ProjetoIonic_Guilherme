import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { infoPiu } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';



@IonicPage()
@Component({
  selector: 'page-perfil',
  templateUrl: 'perfil.html',
})
export class PerfilPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private _http: HttpClient) {
  }

  public id = this.navParams.get("idSelect")

  public nome = this.navParams.get("nome")

  public user = this.navParams.get("user")

  public sobrenome = this.navParams.get("sobrenome")

  public pius: infoPiu[] = [];

  public numPost: number = 0
  
  pegarPius(){
    return this._http.get<infoPiu[]>("http://piupiuwer.polijunior.com.br/api/pius?usuario="+this.id)
  }

  atualizaPius(){
    this.pegarPius()
      .subscribe(
        (pius) => {this.pius = pius
        this.numPost = this.pius.length},

        () => {alert("erro")}
     );
      console.log(this.pius)}


  ionViewDidLoad() {
    this.atualizaPius();
  }

}
