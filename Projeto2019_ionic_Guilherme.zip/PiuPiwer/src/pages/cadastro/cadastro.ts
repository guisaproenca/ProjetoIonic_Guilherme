import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { user } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-cadastro',
  templateUrl: 'cadastro.html',
})
export class CadastroPage {

  public email: string = ""
  public usuario: string = ""
  public nome: string = ""
  public sobrenome: string = ""
  public senha: string = ""
  public confirm: string = ""

  public _url: string = "piupiuwer.polijunior.com.br/api/"

  constructor(public navCtrl: NavController, public navParams: NavParams, private _http: HttpClient) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CadastroPage');
  }

  cadastro(){
    let user: user = {
      email: this.email,
      username: this.usuario,
      first_name: this.nome,
      last_name: this.sobrenome,
      password: this.senha
    }

    if(!this.email || !this.usuario || !this.nome || !this.sobrenome || !this.senha || !this.confirm){
      alert("Todos os campos são obrigatórios")
    }

    else if(this.senha != this.confirm){
      alert("Os dois campos de senha não são compatíveis")
    }
    

    else{

      return this._http.post("http://piupiuwer.polijunior.com.br/api/usuarios/registrar/", JSON.stringify(user), 
        {
          headers: new HttpHeaders().set('Content-Type', 'application/json'),
          params: new HttpParams()
          .set("email", this.email)
          .set("username", this.usuario)
          .set("first_name", this.nome)
          .set("last_name", this.sobrenome)
          .set("password", this.senha)
        }
      )
        .subscribe(
          (res) => {
            this.navCtrl.push(LoginPage);
            alert("Cadastrado com sucesso!")
            console.log(res)       
          },
          
          (err) => {
            if(err.error.username){
              alert("Usuário já existente")
            }
            
            else if(err.error.email){
              alert("Email inválido")
            }
            
            else{
            console.log(err.error)
            }
            
          }
        ) 
    }
    
}
}
