import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { infoPiu } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { EditPage } from '../edit/edit';



@IonicPage()
@Component({
  selector: 'page-feed',
  templateUrl: 'feed.html',
})
export class FeedPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private _http: HttpClient) {
  }

  public id = this.navParams.get("idSelect")

  public user = this.navParams.get("user")
  
  public pius: infoPiu[] = [];

  public numPost: number = 0
  
  pegarPius(){
    return this._http.get<infoPiu[]>("http://piupiuwer.polijunior.com.br/api/pius?usuario="+this.id)
  }

  atualizaPius(){
    this.pegarPius()
      .subscribe(
        (pius) => {this.pius = pius
        this.numPost = this.pius.length},

        () => {alert("erro")}
     );
  }

  edit(){
    this.navCtrl.push(EditPage,{id: this.id}
      )
  }


  ionViewDidLoad() {
    this.atualizaPius();
  }

}
