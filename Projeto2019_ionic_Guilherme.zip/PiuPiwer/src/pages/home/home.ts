import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { CadastroPage } from '../cadastro/cadastro';
import { login, piu, tokenUser } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { FeedPage } from '../feed/feed'
import { infoPiu } from '../../modelos/modelos'
import { PerfilPage } from '../perfil/perfil';
import { ElementRef } from '@angular/core'



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {


  constructor(public navCtrl: NavController, private _http: HttpClient,public navParams: NavParams) {

  }

  //aqui declaro as variáveis que uso na página

    public pius: infoPiu[] = [];

    public usuario = {}
    
    public id: string = ""

    public post: string = ""

    public infos = this.navParams.get("infos")

    public globalToken = this.infos.token

    public decodedJSON: string

    public idUser: tokenUser = {
      userID: "",
      username: "",
      email: ""
    }

  pegarPius(){
    return this._http.get<infoPiu[]>('http://piupiuwer.polijunior.com.br/api/pius/')
  }

  //função para pegar os pius da api, usando o post acima
  atualizaPius(){
    this.pegarPius()
      .subscribe(
        (pius) => {this.pius = pius},

        () => {alert("erro")}
      );
  }
  
  pagPerf(piu){
    this.navCtrl.push(PerfilPage,{
      idSelect: piu.usuario.id, 
      user: piu.usuario.username,
      nome: piu.usuario.first_name,
      sobrenome: piu.usuario.last_name
    }
      )
    
  }

 pagUser(){this.navCtrl.push(FeedPage,{
   idSelect: this.idUser.userID,
   user: this.idUser.username,
  })
   
 }

  postar(){
    if(this.post == ""){alert("não pode mandar um piu vazio")}

    let piu: piu = {
      favoritado: "false",
      conteudo: this.post,
      data: new Date().toISOString()
}

    return this._http.post("http://piupiuwer.polijunior.com.br/api/pius/", JSON.stringify(piu), {
        headers: new HttpHeaders().set('Content-Type', 'application/json'),
        params: new HttpParams()
        .set("favoritado", piu.favoritado )
        .set("conteudo", piu.conteudo )
        .set("data", piu.data)
    })
        .subscribe(
          () => {console.log("sucesso")
            },
          
          () => {
                console.log("erro")
            }
        )

      }
    
      tokenDecode() {
        const token = this.globalToken;
        let payload;
        if (token) {
          payload = token.split(".")[1];
          payload = window.atob(payload);
          this.decodedJSON = JSON.parse(payload);
          this.idUser.userID = this.decodedJSON['user_id'];
          this.idUser.username = this.decodedJSON['username'];
          this.idUser.email = this.decodedJSON['email']
          return true;
        } else {
          return false;
        }
      }


      favoritado(piu){
        if (piu.favoritado = false){
          piu.favoritado = true
          
        }

      }

  ionViewDidLoad() {
    this.atualizaPius()
    this.tokenDecode()
    console.log(this.decodedJSON)
  }
    
}