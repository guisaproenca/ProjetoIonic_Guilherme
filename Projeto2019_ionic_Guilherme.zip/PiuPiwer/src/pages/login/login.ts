import { Component } from '@angular/core';
import { NavController, IonicPage } from 'ionic-angular';
import { CadastroPage } from '../cadastro/cadastro';
import { login } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { HomePage } from '../home/home';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/observable/fromPromise';
import 'rxjs/add/operator/mergeMap';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  constructor(public navCtrl: NavController, private _http: HttpClient, private _storage: Storage) {

  }

  prox_pag(){
    this.navCtrl.push(CadastroPage)
  }
  
  public usuario: string= ""
  public senha: string= ""
  public tok: string=""

  pagfeed(){
    this.navCtrl.push(HomePage, {infos: this.logi}
      )
  }

  salva(logi: login) {
    let promise = this._storage.set("", logi);

    return Observable.fromPromise(promise);
  }
  
  public logi: login = {
    username: this.usuario,
    password: this.senha,
    token: this.tok
  }

  login(){

    this.logi.username = this.usuario
    this.logi.password = this.senha

    return this._http.post("http://piupiuwer.polijunior.com.br/api/login/", JSON.stringify(this.logi), {
        headers: new HttpHeaders().set('Content-Type', 'application/json'),
        params: new HttpParams()
        .set("username", this.logi.username)
        .set("password", this.logi.password)
    })
        .subscribe(
          (res) => {
            
            this.logi.token = res.token
            this.pagfeed();

          },
          
          () => {
                alert("Usuário ou senha incorretos")
            }
        )
  }
}
