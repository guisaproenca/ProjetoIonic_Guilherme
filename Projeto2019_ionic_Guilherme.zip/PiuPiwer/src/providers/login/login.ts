import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { user } from '../../modelos/modelos';


@Injectable()
export class LoginProvider {

  constructor(public _http: HttpClient) {
    
  }

  public url: "http://piupiuwer.polijunior.com.br/api/"

  LoginPost(obj: user){
    console.log(obj.username)
    console.log(obj.password)
    return this._http.post(this.url+"login/", JSON.stringify(obj), {
      headers: new HttpHeaders().set('Content-Type', 'application/json'),
      params: new HttpParams()
      .set("username", obj.username)
      .set("password", obj.password)
    }
    )
  }

}
