export interface user {
    email: string
    username: string
    first_name: string
    last_name: string
    password: string
}

export interface login{
    username: string
    password: string
    token: string
}

export interface infoPiu{
    id: number,
    favoritado: boolean,
    conteudo: string,
    data: Date,
    usuario: usuario,
}

export interface piu{
    favoritado: string
    conteudo: string
    data: string
}

export interface usuario{
    id: number,
    username: string
    first_name: string
    last_name: string
    email: string
}

export interface tokenUser {
    userID: string
    username: string
    email: string
}